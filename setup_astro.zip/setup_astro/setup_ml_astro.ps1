

# ==========================================================
#  setup_ml_astro.ps1
#  Author: Masoom
#  Purpose: Full-featured Windows 11 setup for
#           ML, AI, DSA, Astronomy, AstroML, GIS, GeoPandas,
#           Polars, Xarray, and extended astroinformatics tools
# ==========================================================

Write-Host "🚀 Starting setup for ML + AI + Astro + GIS environment..." -ForegroundColor Cyan

# ---------------------------
# STEP 0: Ensure script execution is allowed
# ---------------------------
Write-Host "🔐 Checking PowerShell execution policy..." -ForegroundColor Yellow
try {
    $currentPolicy = Get-ExecutionPolicy -Scope CurrentUser
    if ($currentPolicy -ne "RemoteSigned" -and $currentPolicy -ne "Unrestricted") {
        Write-Host "🛠️  Setting ExecutionPolicy to RemoteSigned for current user..." -ForegroundColor Cyan
        Set-ExecutionPolicy RemoteSigned -Scope CurrentUser -Force
    } else {
        Write-Host "✅ ExecutionPolicy is already set to: $currentPolicy" -ForegroundColor Green
    }
} catch {
    Write-Host "⚠️ Could not verify or set ExecutionPolicy. Try running as Administrator if issues occur." -ForegroundColor Red
}

# ---------------------------
# STEP 1: Install Core Tools
# ---------------------------
Write-Host "🔧 Checking and installing core tools..." -ForegroundColor Yellow

# Update all existing winget packages
winget upgrade --all --accept-source-agreements --accept-package-agreements

# Install Git, Python, and VS Code if not present
winget install -e --id Git.Git -h --accept-source-agreements --accept-package-agreements
winget install -e --id Python.Python.3.11 -h --accept-source-agreements --accept-package-agreements
winget install -e --id Microsoft.VisualStudioCode -h --accept-source-agreements --accept-package-agreements

# ---------------------------
# STEP 2: Create Virtual Environment
# ---------------------------
Write-Host "🐍 Setting up Python virtual environment..." -ForegroundColor Yellow

$envName = "ml_env"
$pythonPath = "C:\Users\$env:USERNAME\AppData\Local\Programs\Python\Python311\python.exe"

if (-Not (Test-Path $pythonPath)) {
    Write-Host "⚠️ Python path not found — using default python command."
    $pythonPath = "python"
}

& $pythonPath -m venv $envName
& ".\$envName\Scripts\activate.ps1"

pip install --upgrade pip setuptools wheel

# ---------------------------
# STEP 3: Core ML + DSA Stack
# ---------------------------
Write-Host "📦 Installing base DSA + ML + AI libraries..." -ForegroundColor Yellow
pip install numpy pandas scikit-learn matplotlib seaborn jupyterlab scipy joblib tqdm

# ---------------------------
# STEP 4: Astronomy / AstroML Stack
# ---------------------------
Write-Host "🌌 Installing astronomy libraries..." -ForegroundColor Yellow
pip install astropy astroquery astroML photutils specutils sunpy reproject astroalign `
           dustmaps healpy regions aplpy spacepy poliastro astroplan

# ---------------------------
# STEP 5: GIS / Geospatial Stack
# ---------------------------
Write-Host "🗺️ Installing geospatial & remote sensing libraries..." -ForegroundColor Yellow
pip install geopandas shapely fiona pyproj rtree rasterio rasterstats contextily pyogrio `
           cartopy folium mapclassify geopy elevation richdem pydeck geemap

# ---------------------------
# STEP 6: High-Performance & Scientific Data Tools
# ---------------------------
Write-Host "⚡ Installing Polars, Xarray, and scientific file support..." -ForegroundColor Yellow
pip install polars xarray netCDF4 h5py zarr dask[complete] pint cfgrib intake intake-xarray

# ---------------------------
# STEP 7: AI + Deep Learning (CPU-only)
# ---------------------------
Write-Host "🤖 Installing CPU-friendly ML/AI frameworks..." -ForegroundColor Yellow
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cpu
pip install tensorflow-cpu transformers datasets sentencepiece statsmodels keras opencv-python-headless

# ---------------------------
# STEP 8: Visualization & Analysis Tools
# ---------------------------
Write-Host "📊 Installing visualization & dashboarding tools..." -ForegroundColor Yellow
pip install plotly bokeh folium hvplot holoviews datashader panel seaborn-altair `
           altair seaborn jupyterlab-vim ipywidgets

# ---------------------------
# STEP 9: Notebook & Utility Tools
# ---------------------------
Write-Host "🧰 Installing notebook & dev utilities..." -ForegroundColor Yellow
pip install jupyter jupyterlab jupyterlab-git jupyter_contrib_nbextensions black `
           flake8 isort pre-commit rich loguru

# ---------------------------
# STEP 10: Verify Installation
# ---------------------------
Write-Host "🧪 Verifying installations..." -ForegroundColor Yellow
python - <<EOF
import astropy, astroquery, astroML, geopandas, polars, xarray, torch, tensorflow
print("✅ All major astronomy, GIS, ML libraries loaded successfully!")
EOF

# ---------------------------
# STEP 11: Done!
# ---------------------------
Write-Host "`n🎉 Setup complete!" -ForegroundColor Green
Write-Host "To activate your environment later, run:" -ForegroundColor Green
Write-Host "    .\$envName\Scripts\activate" -ForegroundColor Cyan
Write-Host "`nTo launch JupyterLab:" -ForegroundColor Green
Write-Host "    jupyter lab" -ForegroundColor Cyan
Write-Host "`nEnjoy your ML + AI + Astronomy + GIS environment!" -ForegroundColor Green
