---

## 🪐 **README.md — ML + AI + Astronomy + GIS Environment**

### 📘 Overview

This repository provides a **complete Conda + Docker environment** for:

* **Machine Learning / AI / DSA**
* **Astronomy & Astroinformatics (AstroML, Astropy, etc.)**
* **Geospatial & GIS analysis (GeoPandas, Rasterio, Xarray, etc.)**
* **High-performance data science (Polars, Dask, Zarr)**
* **Scientific visualization and dashboarding**

It’s designed for **Windows 11**, **macOS**, and **Linux**, and runs equally well **locally (Miniconda)** or inside **Docker**.

---

### 🧰 Contents

| File                 | Description                                                           |
| -------------------- | --------------------------------------------------------------------- |
| `environment.yml`    | Defines the full Conda environment for ML, AI, Astronomy & GIS.       |
| `Dockerfile`         | Builds a reproducible Docker image using the same environment.        |
| `setup_ml_astro.ps1` | (Optional) PowerShell script for local Windows setup using Miniconda. |

---

### 🚀 Quick Start (Docker)

#### **1️⃣ Build the Docker Image**

Make sure both files (`Dockerfile` and `environment.yml`) are in the same directory, then run:

```bash
docker build -t ml-astro-env .
```

*(First build may take 20–40 minutes depending on internet speed — it’s installing full scientific/GIS stacks.)*

---

#### **2️⃣ Run the Container**

Run the container interactively and mount your local folder:

```bash
docker run -it --rm -p 8888:8888 -v ${PWD}:/workspace -w /workspace ml-astro-env
```

You’ll see a JupyterLab startup message with a URL like:

```
http://127.0.0.1:8888/?token=...
```

Open that link in your browser to start working.

---

#### **3️⃣ Container Details**

* 🐍 Python version: **3.11**
* 🧠 Conda environment: **ml_astro_env**
* 📦 Channels: `conda-forge`, `defaults`
* 🔍 JupyterLab preinstalled and auto-launched
* 🧭 Port: `8888` (JupyterLab)
* 📂 Volume: current folder mounted at `/workspace`

---

### ⚙️ Local Setup (Without Docker)

If you prefer running locally (and already have **Miniconda** or **Anaconda**):

```bash
conda env create -f environment.yml
conda activate ml_astro_env
jupyter lab
```

---

### 🧠 Included Key Libraries

#### 🪐 **Astronomy / Astroinformatics**

`astropy`, `astroquery`, `astroML`, `photutils`, `specutils`,
`sunpy`, `astroalign`, `poliastro`, `astroplan`, `dustmaps`, `aplpy`, `healpy`, `reproject`

#### 🗺️ **GIS / Geospatial**

`geopandas`, `shapely`, `fiona`, `rasterio`, `pyproj`,
`cartopy`, `contextily`, `geemap`, `richdem`, `folium`, `rasterstats`, `mapclassify`

#### ⚙️ **Data / HPC / File Formats**

`polars`, `xarray`, `dask`, `zarr`, `netCDF4`, `cfgrib`, `h5py`, `intake`, `intake-xarray`

#### 🤖 **ML + AI (CPU)**

`torch` (CPU build), `tensorflow-cpu`, `transformers`, `datasets`, `keras`, `scikit-learn`, `statsmodels`, `opencv-python-headless`

#### 📊 **Visualization / Dashboards**

`matplotlib`, `plotly`, `bokeh`, `holoviews`, `hvplot`, `datashader`, `panel`, `altair`, `ipywidgets`

#### 🧩 **Developer Tools**

`jupyterlab`, `black`, `flake8`, `isort`, `rich`, `loguru`, `pre-commit`, `jupyterlab-vim`, `jupyter_contrib_nbextensions`

---

### 🧱 VS Code Dev Container (Optional)

You can also open this environment directly inside VS Code using the **Dev Containers** extension.

Create a file at `.devcontainer/devcontainer.json`:

```json
{
  "name": "ML Astro Env",
  "build": { "dockerfile": "../Dockerfile" },
  "forwardPorts": [8888],
  "workspaceFolder": "/workspace",
  "settings": {
    "python.defaultInterpreterPath": "/opt/conda/envs/ml_astro_env/bin/python"
  },
  "extensions": [
    "ms-python.python",
    "ms-toolsai.jupyter",
    "ms-python.vscode-pylance"
  ]
}
```

Then:
**Ctrl + Shift + P → “Dev Containers: Reopen in Container”**

---

### 🧹 Maintenance

| Command                                        | Purpose                       |
| ---------------------------------------------- | ----------------------------- |
| `conda env update -f environment.yml --prune`  | Update local environment      |
| `docker system prune -a`                       | Clean up unused Docker images |
| `conda remove -n ml_astro_env --all`           | Remove environment            |
| `docker save ml-astro-env -o ml_astro_env.tar` | Export Docker image           |

---

### 📦 Example Folder Layout

```
ml_astro_project/
│
├── environment.yml
├── Dockerfile
├── setup_ml_astro.ps1
├── README.md
└── notebooks/
    ├── astro_analysis.ipynb
    ├── gis_mapping.ipynb
    └── ml_pipeline.ipynb
```

---

### ✨ Credits

**Author:** VASCSC AStronomy Lab
**Purpose:** Unified Conda + Docker environment for scientific analysis across ML, AI, Astronomy, and GIS.

---