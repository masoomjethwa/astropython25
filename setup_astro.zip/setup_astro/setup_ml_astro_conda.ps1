# ==========================================================
#  setup_ml_astro.ps1
#  Author: ChatGPT (GPT-5)
#  Purpose: Create a Conda environment for ML, AI, DSA,
#           Astronomy, AstroML, GIS, GeoPandas, Polars, Xarray,
#           and extended astroinformatics analysis.
# ==========================================================

Write-Host "🚀 Starting Miniconda environment setup for ML + AI + Astro + GIS..." -ForegroundColor Cyan

# ---------------------------
# STEP 0: Ensure script execution is allowed
# ---------------------------
Write-Host "🔐 Checking PowerShell execution policy..." -ForegroundColor Yellow
try {
    $currentPolicy = Get-ExecutionPolicy -Scope CurrentUser
    if ($currentPolicy -ne "RemoteSigned" -and $currentPolicy -ne "Unrestricted") {
        Write-Host "🛠️  Setting ExecutionPolicy to RemoteSigned for current user..." -ForegroundColor Cyan
        Set-ExecutionPolicy RemoteSigned -Scope CurrentUser -Force
    } else {
        Write-Host "✅ ExecutionPolicy is already set to: $currentPolicy" -ForegroundColor Green
    }
} catch {
    Write-Host "⚠️ Could not verify or set ExecutionPolicy. Try running as Administrator if issues occur." -ForegroundColor Red
}

# ---------------------------
# STEP 1: Check for Conda
# ---------------------------
Write-Host "🧩 Checking Miniconda/Conda installation..." -ForegroundColor Yellow
$conda = Get-Command conda -ErrorAction SilentlyContinue
if (-not $conda) {
    Write-Host "❌ Conda not found. Please install Miniconda or Anaconda before running this script." -ForegroundColor Red
    exit 1
} else {
    Write-Host "✅ Conda detected." -ForegroundColor Green
}

# ---------------------------
# STEP 2: Update Conda
# ---------------------------
Write-Host "🔄 Updating Conda..." -ForegroundColor Yellow
conda update -n base -c defaults conda -y

# ---------------------------
# STEP 3: Create Environment
# ---------------------------
$envName = "ml_astro_env"
Write-Host "🌱 Creating new conda environment: $envName" -ForegroundColor Yellow

# Remove if exists (optional)
conda remove -n $envName --all -y 2>$null

# Create environment with key libraries from conda-forge
conda create -n $envName -c conda-forge python=3.11 -y `
    numpy pandas scikit-learn scipy matplotlib seaborn jupyterlab joblib tqdm `
    astropy astroquery astroML photutils specutils sunpy reproject astroalign `
    dustmaps healpy regions aplpy spacepy poliastro astroplan `
    geopandas shapely fiona pyproj rtree rasterio rasterstats contextily pyogrio `
    cartopy folium mapclassify geopy elevation richdem pydeck geemap `
    polars xarray netcdf4 h5py zarr dask pint cfgrib intake intake-xarray `
    plotly bokeh hvplot holoviews datashader panel altair ipywidgets black flake8 isort rich loguru

Write-Host "✅ Base conda packages installed successfully." -ForegroundColor Green

# ---------------------------
# STEP 4: Activate Environment
# ---------------------------
Write-Host "🔄 Activating environment..." -ForegroundColor Yellow
conda activate $envName

# ---------------------------
# STEP 5: Install Pip-only Packages
# ---------------------------
Write-Host "📦 Installing pip-only libraries (PyTorch, TensorFlow, Transformers, etc.)..." -ForegroundColor Yellow
pip install --upgrade pip setuptools wheel
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cpu
pip install tensorflow-cpu transformers datasets sentencepiece statsmodels keras opencv-python-headless jupyter_contrib_nbextensions seaborn-altair jupyterlab-vim pre-commit

# ---------------------------
# STEP 6: Verify Installations
# ---------------------------
Write-Host "🧪 Verifying core packages..." -ForegroundColor Yellow
python - <<EOF
import astropy, astroquery, astroML, geopandas, polars, xarray, torch, tensorflow
print("✅ All major astronomy, GIS, ML libraries loaded successfully!")
EOF

# ---------------------------
# STEP 7: Done!
# ---------------------------
Write-Host "`n🎉 Setup complete!" -ForegroundColor Green
Write-Host "To activate your conda environment later, run:" -ForegroundColor Green
Write-Host "    conda activate $envName" -ForegroundColor Cyan
Write-Host "`nTo launch JupyterLab:" -ForegroundColor Green
Write-Host "    jupyter lab" -ForegroundColor Cyan
Write-Host "`nEnjoy your Conda-powered ML + AI + Astronomy + GIS environment!" -ForegroundColor Green

#conda activate ml_astro_env
#jupyter lab
